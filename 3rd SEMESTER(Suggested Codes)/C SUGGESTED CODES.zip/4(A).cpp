// 4(A) To display our College name twenty times on screen.

# include <stdio.h>
int main()
{
	int i;
	char name[50] = "TECHNO INDIA UNIVERSITY";	
	for(i=1;i<=20;i++)
	{
		printf("%s\n", name);
	}
}


