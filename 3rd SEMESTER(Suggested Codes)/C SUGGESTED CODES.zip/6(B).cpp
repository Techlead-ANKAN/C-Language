// 6(B) To find the sum of the series 1 + + ? for n = 1, x = 0 1! 2! n! using function.

