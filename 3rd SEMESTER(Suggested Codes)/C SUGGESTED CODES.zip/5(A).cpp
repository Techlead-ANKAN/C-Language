// 5(A)To find the largest and smallest numbers from array elements.

# include <stdio.h>
int main()
{
	int arr[5] = {1,4,5,2,8};
	int *p;
	p = arr;
	int max,i;
	
	printf("Address is: %p", *p);
	
}
