//6(C) To interchange the biggest and smallest number in to calculate factorial a one-dimensional array using function.
